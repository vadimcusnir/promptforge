# KPI Matrix — Creator Commerce Pack

| KPI             | Prag/Target | Metodă de măsurare                 | Frecvență |
|-----------------|-------------|------------------------------------|-----------|
| CR Uplift | ≥ +15% | definire standard | săpt./lunar |
| K-Factor | > 1.0 | definire standard | săpt./lunar |
| Retention D30 | ≥ 35% | definire standard | săpt./lunar |
