# Implementation Checklist – Creator Commerce Pack

## 1. Setup (Pregătire)
- [ ] Adună requirements din `overview.md`  
- [ ] Configurează contextul în Panoul PROMPTFORGE  
- [ ] Setează folderul `/cases/` pentru hash + scoruri  
- [ ] Confirmă guardrails

## 2. Generare
- [ ] Rulează Prompt A + B pentru fiecare modul  
- [ ] Validează în Test Engine (Structură ≥90, Claritate ≥88)  
- [ ] Salvează output JSON în `/specs/output_templates.json`

## 3. Integrare
- [ ] Importă output în Shopify, VTEX, Klaviyo, Mailchimp  
- [ ] Activează fluxurile conform `spec`  
- [ ] Atașează checklist guardrails per modul

## 4. Validare
- [ ] Măsoară baseline KPI  
- [ ] Rulează testul și compară uplift  
- [ ] Notează status: hit / warn / miss

## 5. Raportare
- [ ] Actualizează `/kpi/kpi_dashboard.json`  
- [ ] Atașează hash + timestamp  
- [ ] Arhivează loguri în `/history/`

## 6. Guardrails – Do/Don’t
| Domeniu  | Do                               | Don’t                         |
|---------|-----------------------------------|-------------------------------|
| Copy    | Claritate + structură             | Promisiuni nerealiste         |
| Etică   | Transparență, consimțământ        | Colectare date neautorizată   |
| KPI     | Respectă pragurile de validare    | Publicare sub prag            |
