# Promptforge™ Module Pack License

## 1. Termeni de Utilizare
– Single User / Team ≤5 / Enterprise

## 2. Update-uri
– 12 luni incluse, apoi opțiune de reînnoire

## 3. Restricții
– Redistribuire publică interzisă; interzisă ștergerea hash/watermark

## 4. Protecție
– Hash unic în `hash.txt`; watermark JSON în `kpi_dashboard.json`

## 5. Anti-Abuz & Audit
– Respectă guardrails; PROMPTFORGE poate solicita fișiere pentru verificarea hash-ului
