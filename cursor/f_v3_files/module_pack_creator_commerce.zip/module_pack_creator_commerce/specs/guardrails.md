# Guardrails – Creator Commerce Pack

## Reguli generale
– Etică, transparență, conformitate (GDPR)  
– Fără promisiuni nerealiste, fără clickbait excesiv  
– Respectă scoruri minime (Structură≥90 / Claritate≥88)

## Module-specifice
– Completează Do/Don’t pe fiecare modul în `/prompts/` când umpli prompts
