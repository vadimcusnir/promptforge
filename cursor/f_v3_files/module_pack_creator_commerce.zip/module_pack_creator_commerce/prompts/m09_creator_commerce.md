# Modul M09 – Post-Purchase Subscription Engine

---

## 1. Prompt Industrial (Varianta A)
[Scrie promptul principal, complet, cu placeholders.]

## 2. Prompt Industrial (Varianta B – A/B testing)
[Scrie variantă alternativă.]

## 3. Requirements (Inputuri Obligatorii)
– [PRODUS] – [PUBLIC_TINTA] – [CANAL] – [KPI_TARGET] – [CONTEXT]

## 4. Spec (Pași Pipeline)
– Pas 1: Preia inputuri → Pas 2: Generează text → Pas 3: Validează (Test Engine) → Pas 4: Output JSON

## 5. Output Template (JSON)
```json
{
  "headline": "string",
  "body": "string",
  "cta": "string",
  "kpi_target": "string"
}
```

## 6. Guardrails (Etică & Limitări)
– Fără promisiuni nerealiste. – Evită limbaj manipulator. – Respectă transparența (GDPR).
